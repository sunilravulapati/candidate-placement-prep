# Find Median from Data Stream — Editorial

## Overview
Design a structure that supports adding numbers and finding the median.

## Why Learn This?
Advanced hard-level problem testing deep problem-solving skills, optimal state management, and algorithmic rigor.

## Recognition Clues
Look for array/string traversal where heap properties or sliding boundaries reduce time complexity.

## Prerequisites
Mastery of heap, dynamic programming, advanced graph/tree traversal

## Concepts Used
Complex Heap algorithms, state compression, optimization

## Intuition & Approach
### Intuition
By maintaining optimal state or invariants during iteration, we avoid recomputing redundant subproblems.

### Approach
Leverage advanced heap algorithms, multi-dimensional DP, or monotonic data structures to achieve optimal asymptotic bounds.

## Step-by-Step Algorithm
1. Initialize data structures (PriorityQueue (Min/Max Heap)).
2. Traverse input while updating current boundary or accumulator.
3. Return result once target state is reached.

## Pseudocode
```text
# Hard Heap optimal approach
initialize state table / priority queue
while queue or states active:
  transition states
return target result
```

## Complexity Analysis
- **Optimal Time Complexity:** O(N log N) or O(N)
- **Optimal Space Complexity:** O(N)
- **Brute Force Time Complexity:** O(2^N) / O(N^3)
- **Brute Force Space Complexity:** O(N^2)

## Common Mistakes & Gotchas
- Overcomplicating the state transitions or missing crucial base cases.

## Edge Cases to Consider
- Maximum constraint bounds, disconnected components, boundary overflow.

## Interview Trick
Focus on invariant preservation and spatial optimization (in-place manipulation where applicable).

## Revision Notes
Key Heap question frequently asked in FAANG/Top Tech interview loops.
